<?php
include 'functions.php';
?>

<?=template_header('Home')?>

<div class="content">
	<h2>Home</h2>
	<p>Welcome to the home page in Women In Tech Comunity!</p>
</div>

<?=template_footer()?>